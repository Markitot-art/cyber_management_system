<?php
// SECURITY: this file was publicly accessible and contained a real
// plaintext admin password in the source, visible to anyone who requested
// this URL. That password should be treated as compromised.
//
// This tool is still useful for generating bcrypt hashes, but it now
// requires an admin login and no longer ships with a real password baked in.
require_once 'config.php';
if (!isLoggedIn() || ($_SESSION['role'] ?? '') !== 'admin') {
    die('Access denied. Admin only. Please log in as an administrator first.');
}

// Change this to whatever password you want to hash, then delete this file
// (or at least this line) once you're done using it.
$my_password = "CHANGE_ME";

// Generate hash using the same method as your system
$hashed_password = password_hash($my_password, PASSWORD_DEFAULT);

// Display the hash
echo "========================================\n";
echo "Your password: " . $my_password . "\n";
echo "========================================\n";
echo "HASH TO COPY:\n";
echo $hashed_password . "\n";
echo "========================================\n";
echo "\n";
echo "Run this SQL to update admin password:\n";
echo "UPDATE users SET password = '" . $hashed_password . "' WHERE user_id = 1;\n";
echo "========================================\n";
?>
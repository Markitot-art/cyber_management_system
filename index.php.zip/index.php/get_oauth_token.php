<?php
// SECURITY: this was an unused, unmodified PHPMailer example script for
// setting up OAuth2 email sending. It was never wired into config.php
// (SMTP_PASSWORD / basic auth is used instead), so it was just extra
// public attack surface. Disabled. Safe to delete this file entirely.
http_response_code(404);
exit;

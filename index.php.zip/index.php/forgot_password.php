<?php
require_once 'config.php';

$error = '';
$success = '';
$show_direct_link = false; // SECURITY: must stay false in production - showing the link
// directly on-screen lets anyone reset any account without owning the email address.
$show_request_form = true;
$show_reset_form = false;
$reset_user = null;
$token = '';

function getResetUser($conn, $token) {
    $query = "SELECT user_id, username, full_name, email FROM users WHERE reset_token = ? AND reset_expires > NOW()";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = ($result && $result->num_rows === 1) ? $result->fetch_assoc() : null;
    $stmt->close();
    return $user;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['reset_code'])) {
        $token = isset($_POST['reset_code']) ? sanitize($conn, $_POST['reset_code']) : '';
        $reset_user = getResetUser($conn, $token);

        if (!$reset_user) {
            $error = "Invalid or expired reset link. Please request a new password reset.";
        } else {
            $show_reset_form = true;
            $password = $_POST['password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';

            if (empty($password)) {
                $error = "Please enter a password";
            } elseif (strlen($password) < 8) {
                $error = "Password must be at least 8 characters long";
            } elseif (!preg_match('/[A-Z]/', $password)) {
                $error = "Password must contain at least one uppercase letter";
            } elseif (!preg_match('/[a-z]/', $password)) {
                $error = "Password must contain at least one lowercase letter";
            } elseif (!preg_match('/[0-9]/', $password)) {
                $error = "Password must contain at least one number";
            } elseif (!preg_match('/[!@#$%^&*(),.?\":{}|<>]/', $password)) {
                $error = "Password must contain at least one special character";
            } elseif ($password !== $confirm_password) {
                $error = "Passwords do not match";
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $update_query = "UPDATE users SET password = ?, reset_token = NULL, reset_expires = NULL WHERE user_id = ?";
                $update_stmt = $conn->prepare($update_query);
                $update_stmt->bind_param("si", $hashed_password, $reset_user['user_id']);

                if ($update_stmt->execute()) {
                    $success = "Password has been reset successfully! You can now login with your new password.";
                    $show_request_form = false;
                } else {
                    $error = "An error occurred. Please try again.";
                    $show_reset_form = true;
                }
                $update_stmt->close();
            }
        }
    } else {
        $email = isset($_POST['email']) ? sanitize($conn, $_POST['email']) : '';

        if (empty($email)) {
            $error = "Please enter your email address or username";
        } else {
            $query = "SELECT user_id, username, full_name, email FROM users WHERE email = ? OR username = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ss", $email, $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows == 1) {
                $user = $result->fetch_assoc();

                if (empty($user['email'])) {
                    $error = "This account has no email address on file. Contact the system administrator.";
                } else {
                    $token = bin2hex(random_bytes(16));
                    $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

                    $update_query = "UPDATE users SET reset_token = ?, reset_expires = ? WHERE user_id = ?";
                    $update_stmt = $conn->prepare($update_query);
                    $update_stmt->bind_param("ssi", $token, $expires, $user['user_id']);

                    if ($update_stmt->execute()) {
                        $reset_link = SITE_URL . 'forgot_password.php?code=' . urlencode($token);

                        if ($show_direct_link) {
                            $success = "Forgot password link generated: <br><a href='{$reset_link}' class='btn btn-primary mt-2'>Click here to reset password</a>";
                            $success .= "<br><small class='text-muted'>Email sending is disabled for testing.</small>";
                        } else {
                            $subject = 'PNP ACG Password Reset Request';
                            $body = "
                            <html>
                            <head>
                                <style>
                                    body { font-family: Arial, sans-serif; }
                                    .container { padding: 20px; background: #f4f4f4; }
                                    .content { background: white; padding: 20px; border-radius: 5px; }
                                    .button { 
                                        display: inline-block; 
                                        padding: 10px 20px; 
                                        background: #ce1126; 
                                        color: white; 
                                        text-decoration: none; 
                                        border-radius: 5px;
                                        margin: 10px 0;
                                    }
                                </style>
                            </head>
                            <body>
                                <div class='container'>
                                    <div class='content'>
                                        <h2>Password Reset Request</h2>
                                        <p>Hi " . htmlspecialchars($user['full_name']) . ",</p>
                                        <p>We received a request to reset your password. Click the button below to choose a new password:</p>
                                        <p><a href='{$reset_link}' class='button'>Reset Your Password</a></p>
                                        <p>Or copy this link: <br>{$reset_link}</p>
                                        <p>If you did not request this, please ignore this email.</p>
                                        <p>This link will expire in 1 hour.</p>
                                        <hr>
                                        <small>PNP ACG System</small>
                                    </div>
                                </div>
                            </body>
                            </html>
                            ";

                            $altBody = "Password Reset Request\n\n";
                            $altBody .= "Hi " . $user['full_name'] . ",\n\n";
                            $altBody .= "We received a request to reset your password. Click the link below to choose a new password:\n\n";
                            $altBody .= $reset_link . "\n\n";
                            $altBody .= "If you did not request this, please ignore this email.\n";
                            $altBody .= "This link will expire in 1 hour.\n";

                            $mailError = '';
                            if (sendMail($user['email'], $subject, $body, $altBody, $mailError)) {
                                $success = "A password reset email has been sent to your email address. Please check your inbox.";
                            } else {
                                $error = "Unable to send password reset email. Error: " . htmlspecialchars($mailError);
                            }
                        }
                    } else {
                        $error = "An error occurred. Please try again later.";
                    }
                    $update_stmt->close();
                }
            } else {
                $error = "Email address or username not found in our records.";
            }

            $stmt->close();
        }
    }
} elseif (isset($_GET['code'])) {
    $token = sanitize($conn, $_GET['code']);
    $reset_user = getResetUser($conn, $token);

    if ($reset_user) {
        $show_request_form = false;
        $show_reset_form = true;
    } else {
        $error = "Invalid or expired reset link. Please request a new password reset.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - PNP ACG</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #f3f4f5, #001f3f);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', sans-serif;
        }
        .reset-wrapper {
            width: 100%;
            max-width: 500px;
            padding: 20px;
        }
        .reset-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 40px;
        }
        .btn-reset {
            width: 100%;
            padding: 12px;
            background: #003366;
            color: white;
            border: none;
            border-radius: 10px;
            font-weight: bold;
            transition: 0.3s;
        }
        .btn-reset:hover {
            background: #ce1126;
        }
        .btn-login {
            background: #6c757d;
        }
        .btn-login:hover {
            background: #5a6268;
        }
        .form-group {
            position: relative;
            margin-bottom: 20px;
        }
        .form-control {
            padding: 12px 15px 12px 45px;
            border-radius: 10px;
        }
        .input-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
        }
        .alert a {
            color: white;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="reset-wrapper">
        <div class="reset-card">
            <div class="text-center mb-4">
                <i class="fas fa-key" style="font-size: 48px; color: #003366;"></i>
                <h3 class="mt-3"><?php echo $show_reset_form ? 'Reset Password' : 'Forgot Password?'; ?></h3>
                <p class="text-muted"><?php echo $show_reset_form ? 'Create a new secure password' : 'Enter your email address or username to reset your password'; ?></p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($show_reset_form && !$success): ?>
                <form method="POST">
                    <input type="hidden" name="reset_code" value="<?php echo htmlspecialchars($token); ?>">
                    <div class="form-group">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="password" name="password" class="form-control" placeholder="New Password" required autofocus>
                    </div>
                    <div class="form-group">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="password" name="confirm_password" class="form-control" placeholder="Confirm New Password" required>
                    </div>
                    <button type="submit" class="btn-reset">
                        <i class="fas fa-save"></i> Reset Password
                    </button>
                </form>
            <?php elseif ($show_request_form && !$success): ?>
                <form method="POST">
                    <div class="form-group">
                        <i class="fas fa-envelope input-icon"></i>
                        <input type="text" name="email" class="form-control" placeholder="Email address or username" required autofocus>
                    </div>
                    
                    <button type="submit" class="btn-reset">
                        <i class="fas fa-paper-plane"></i> Send Reset Link
                    </button>
                </form>
            <?php endif; ?>
            
            <div class="text-center mt-4">
                <a href="index.php" class="text-decoration-none">
                    <i class="fas fa-arrow-left"></i> Back to Login
                </a>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
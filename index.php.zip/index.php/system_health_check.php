<?php
require_once 'config.php';

// SECURITY: this page used to be public and revealed server/filesystem
// details to anyone. Restrict it to logged-in admins.
if (!isLoggedIn() || ($_SESSION['role'] ?? '') !== 'admin') {
    die('Access denied. Admin only. Please log in as an administrator first.');
}

echo "<h2>PNP ACG System Health Check</h2>";

$checks = [
    "Database Connection" => $conn->ping(),
    "Sessions Enabled" => session_status() === PHP_SESSION_ACTIVE,
    "Uploads Folder" => is_dir("complainant_photos"),
    "Video Folder" => is_dir("videos"),
];

echo "<table border='1' cellpadding='10'>";
echo "<tr><th>Check</th><th>Status</th></tr>";

foreach($checks as $label => $status){
    echo "<tr>";
    echo "<td>{$label}</td>";
    echo "<td>" . ($status ? "OK" : "FAILED") . "</td>";
    echo "</tr>";
}

echo "</table>";
?>
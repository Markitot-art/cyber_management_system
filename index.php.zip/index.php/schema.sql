-- ============================================================================
-- PNP ACG Complaint System — Reconstructed Schema
-- NOTE: This was reverse-engineered from the queries in the PHP code, since
-- no schema.sql/backup was included in the uploaded package. Review column
-- types/lengths and adjust before relying on this in production — in
-- particular, add any extra columns your original deployment may have had
-- that aren't touched by these code paths (e.g. unused admin fields).
-- ============================================================================

SET NAMES utf8mb4;

-- ----------------------------------------------------------------------------
-- users: system accounts (investigators, admins, etc.)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,      -- bcrypt hash (MD5 auto-upgraded on login)
    full_name VARCHAR(255) NOT NULL,
    `rank` VARCHAR(100) DEFAULT NULL,
    role VARCHAR(50) DEFAULT 'investigator',
    email VARCHAR(255) DEFAULT NULL,
    reset_token VARCHAR(255) DEFAULT NULL,
    reset_expires DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------------------------------------------------------
-- login_attempts: brute-force lockout tracking
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    identifier VARCHAR(100) NOT NULL,    -- IP address
    attempt_time DATETIME NOT NULL,
    INDEX idx_identifier (identifier)
);

-- ----------------------------------------------------------------------------
-- investigators: roster used for queue rotation / assignment
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS investigators (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL,       -- e.g. 'visit', 'general_cases', 'womens_desk'
    gender VARCHAR(20) DEFAULT NULL,
    status VARCHAR(20) DEFAULT 'active', -- active / inactive
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------------------------------------------------------
-- complainants: walk-in / reporting party details
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS complainants (
    complainant_id INT AUTO_INCREMENT PRIMARY KEY,
    queue_number VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    contact_number VARCHAR(50) DEFAULT NULL,
    email VARCHAR(255) DEFAULT NULL,
    address VARCHAR(500) DEFAULT NULL,
    remarks TEXT DEFAULT NULL,
    visit_reason VARCHAR(255) DEFAULT NULL,
    category VARCHAR(50) NOT NULL,       -- 'visit', 'general_cases', 'womens_desk', etc.
    assigned_investigator VARCHAR(255) DEFAULT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    photo_path VARCHAR(500) DEFAULT NULL,
    is_priority TINYINT(1) DEFAULT 0,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    INDEX idx_queue_number (queue_number),
    INDEX idx_status (status)
);

-- ----------------------------------------------------------------------------
-- complaints: the actual case record, linked to a complainant
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS complaints (
    complaint_id INT AUTO_INCREMENT PRIMARY KEY,
    complainant_id INT NOT NULL,
    queue_number VARCHAR(50) DEFAULT NULL,
    case_type VARCHAR(100) DEFAULT NULL,
    case_status VARCHAR(50) DEFAULT 'open',
    description TEXT DEFAULT NULL,
    date_reported DATETIME DEFAULT NULL,
    incident_date DATE DEFAULT NULL,
    incident_time TIME DEFAULT NULL,
    reported_by INT DEFAULT NULL,        -- FK -> users.user_id
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    INDEX idx_complainant_id (complainant_id),
    INDEX idx_case_status (case_status),
    FOREIGN KEY (complainant_id) REFERENCES complainants(complainant_id) ON DELETE CASCADE,
    FOREIGN KEY (reported_by) REFERENCES users(user_id) ON DELETE SET NULL
);

-- ----------------------------------------------------------------------------
-- queue_history: audit trail of queue actions
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS queue_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    queue_number VARCHAR(50) NOT NULL,
    action VARCHAR(100) NOT NULL,
    message TEXT DEFAULT NULL,
    remarks TEXT DEFAULT NULL,
    performed_by INT DEFAULT NULL,       -- FK -> users.user_id
    created_at DATETIME NOT NULL,
    INDEX idx_queue_number (queue_number)
);

-- ----------------------------------------------------------------------------
-- status_history: audit trail of complaint status changes
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS status_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    complaint_id INT NOT NULL,
    status VARCHAR(50) NOT NULL,
    remarks TEXT DEFAULT NULL,
    created_at DATETIME NOT NULL,
    INDEX idx_complaint_id (complaint_id),
    FOREIGN KEY (complaint_id) REFERENCES complaints(complaint_id) ON DELETE CASCADE
);

-- ----------------------------------------------------------------------------
-- The following tables are already auto-created by the app itself
-- (CREATE TABLE IF NOT EXISTS in the PHP code), included here for completeness
-- so the whole schema can be provisioned in one go.
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS investigator_action_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    investigator_name VARCHAR(255) NOT NULL,
    badge_id VARCHAR(100),
    action_type VARCHAR(50),
    details TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS complaint_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    complainant_id INT,
    complaint_id INT,
    action VARCHAR(100),
    details TEXT,
    performed_by VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS follow_ups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    complainant_id INT NOT NULL,
    complaint_id INT NULL,
    queue_number VARCHAR(50),
    assigned_investigator VARCHAR(255),
    status VARCHAR(50) DEFAULT 'open',
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS investigator_attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    investigator_name VARCHAR(255) NOT NULL,
    attendance_date DATE NOT NULL,
    status ENUM('present', 'absent', 'day_off') DEFAULT 'present',
    notes TEXT,
    marked_by VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_attendance (investigator_name, attendance_date)
);

CREATE TABLE IF NOT EXISTS investigator_rotation (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(50) NOT NULL UNIQUE,
    rotation_index INT DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS investigator_changes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    complaint_id INT NOT NULL,
    old_investigator VARCHAR(255),
    new_investigator VARCHAR(255),
    remarks TEXT,
    changed_by VARCHAR(100),
    changed_at DATETIME,
    INDEX idx_complaint_id (complaint_id)
);

-- ----------------------------------------------------------------------------
-- Seed an initial admin user so you can log in.
-- IMPORTANT: this is a placeholder bcrypt hash for the password "changeme123"
-- Log in once, then change it immediately via the app (or run hash_generator.php
-- to generate a fresh hash and UPDATE it directly in phpMyAdmin).
-- ----------------------------------------------------------------------------
INSERT INTO users (username, password, full_name, `rank`, role, email)
VALUES ('admin', '$2b$12$NUE8oERWZdouxdJXnZDI/eiUrTp2Wfek/MyUnyB0vLQ5jWtwA/T0G', 'Administrator', 'N/A', 'admin', 'admin@example.com');

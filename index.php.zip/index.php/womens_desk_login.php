<?php
require_once 'config.php';

if (!isLoggedIn()) {
    redirect('index.php');
}

redirect('complaint_form.php?category=womens_desk');
exit;



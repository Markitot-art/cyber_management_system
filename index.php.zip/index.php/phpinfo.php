<?php
// SECURITY: this file used to call phpinfo(), exposing full server
// configuration, paths, and loaded modules to anyone on the internet.
// Disabled. Delete this file entirely once you've confirmed the site
// still works without it.
http_response_code(404);
exit;
